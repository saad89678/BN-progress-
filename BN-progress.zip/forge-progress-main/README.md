# forge-progress
A simple but beautiful progress bar. Functional and replaceable with ESX and QB without problem.

![image](https://github.com/C0deForge/forge-progress/assets/125872426/06bd1159-a9e9-4783-b706-ffdbe8e94b67)

![image](https://github.com/C0deForge/forge-progress/assets/125872426/dd72309d-97cd-46f8-95af-ad30a0ac0405)

