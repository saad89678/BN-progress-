Config = { }

Config.Style = {
    backgroundPrimary = 'rgba(27, 27, 27, 0.66)',
    backgroundSecondary = 'rgba(27, 27, 27, 0.77)',
    primaryColor = '#FF0066',
    secondaryColor = '#111111'
}